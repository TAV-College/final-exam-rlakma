import React from 'react';
import { TouchableOpacity, Text, GestureResponderEvent } from 'react-native';

interface CustomButtonProps {
  onPress: (event: GestureResponderEvent) => void;
  title?: string;
  color?: string;
}

const CustomButton: React.FC<CustomButtonProps> = ({ onPress, title, color }) => {
  return (
    <TouchableOpacity
      style={{
        backgroundColor: color || 'blue',
        padding: 10,
        borderRadius: 5,
        alignItems: 'center',
      }}
      onPress={onPress}
    >
      <Text style={{ color: 'white' }}>{title || 'Button'}</Text>
    </TouchableOpacity>
  );
};

export default CustomButton;

