import { StyleSheet } from 'react-native';

import EditScreenInfo from '@/components/EditScreenInfo';
import { Text, View } from '@/components/Themed';
import CustomButton from '../../components/customButton';


export default function TabNewScreen() {
  const handlePress = () => {
    alert('Button pressed!');
  };
  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Tab</Text>
        <CustomButton onPress={handlePress} title="Custom Button" color="green" />
        <CustomButton onPress={handlePress} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  separator: {
    marginVertical: 30,
    height: 1,
    width: '80%',
  },
});
